clc; clear; close all; warning('off');
addpath .\fspackage
addpath .\dataset
addpath .\mrmr_hfs
    
load('Iris.mat');  X=ds(:,1:4);  Y=ds(:,end); % loading the dataset
[features]=mrmr_hfs(X,Y);                     % applying the MRMR-HFS algorithm
fea=features(1:2); plotting(X,Y,features);    %Plotting the dataset after feature selection


    




