curPath = pwd;
curPath = [curPath filesep 'fspackage'];
%% load weka jar, and common interfacing methods.
path(path, [curPath filesep 'lib']);
path(path, [curPath filesep 'lib' filesep 'weka']);
loadWeka([curPath filesep 'lib' filesep 'weka']);

%% feature selection algorithms
path(path,[curPath filesep 'fs_sup_fisher_score']);
path(path,[curPath filesep 'fs_sup_information_gain']);
path(path,[curPath filesep 'fs_sup_relieff']);
% data preprocessors
path(path,[curPath filesep 'preprocessor']);

clear curPath;