% function [features]=best_first(filter,correlation,X)

% This function does the forward search based on filter algorithms and
% similarity measurres.
% In:
%     filter     : 3 x n matrix contains the results of filter algorithms.
%     correlation: n x n matrix contains the results of similarity
%     measures.
%     X          : m x n dataset (m: number of samples, n:number of features)  
         
% Out:
%     features: 1 x ? vector, contains the selected features.

% Copyright (c) 2015 by Mohammad Kazem Ebrahimpour & Mahdi Eftekhari
function [features]=best_first(filter,correlation,X)

[~,n]=size(X);Archive={};count=0;
for k=1:n
    if k==1
        tmp=filter; tmp=sum(tmp.^2)./(size(tmp,2));rcf=tmp;
        rff=ones(1,n); merit=rcf./sqrt(k+(k*(k-1))*(rff));
        [max_val,max_ind]=max(merit);
        Archive{k,1}=max_ind;Archive{k,2}=max_val;merit=0;
    elseif k==2
        F_ind=Archive{end,1};  tmp=filter(:,F_ind);  tmp=repmat(tmp,1,n);
        tmp=sum(tmp.^2)./(size(tmp,1)); temp_new=sum(filter.^2)./size(filter,1);
        rcf=tmp+temp_new;  d=1:n; rff=correlation(F_ind,d);
        merit=rcf./sqrt(k+(k*(k-1))*(rff)); merit(F_ind)=-inf;
        [max_val,max_ind]=max(merit);
        Archive{k,1}=[Archive{end,1},max_ind]; Archive{k,2}=max_val; merit=0;
    elseif k>2
        F_ind=Archive{end,1}; tmp=filter(:,F_ind); tmp=tmp.^2;
        tmp=sum(tmp,2); tmp=repmat(tmp,1,n); f=filter.^2;
        rcf=sum(tmp+f)./size(tmp,1); rcf=reshape(rcf,n,1);
        num=factorial(k)/(factorial(2)*factorial(k-2));
        size_k=length(F_ind); tmp=0;
        for j=1:size_k
            for p=j+1:size_k
                tmp=tmp+correlation(F_ind(j),F_ind(p));
            end
        end
        d=1:n;
        for q=1:length(F_ind)
            a(:,q)=(correlation(F_ind(q),d));
        end
        a=sum(a,2); tmp=repmat(tmp,n,1);
        rff=(tmp+a)./num; merit=rcf./sqrt(k+(k*(k-1)*(rff)));
        merit(F_ind)=-inf;
        [max_val,max_ind]=max(merit);
        Archive{k,1}=[Archive{end,1},max_ind]; Archive{k,2}=max_val; merit=0;
    end
    d=cell2mat(Archive(:,2));
    if k>1
        if d(end)<d(end-1)
            count=count+1;
        else
            count=0;
        end
        if count>=10
            break;
        end
    end
end
d=cell2mat(Archive(:,2)); [~,ind]=max(d); features=Archive{ind,1};
end