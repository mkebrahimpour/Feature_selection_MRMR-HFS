% function [filter_method]=filter_algorithms(X,Y)

% This function calculates the ranking algorithms.
% Three ranking algorithms are: Fisher;Information Gain;ReleifF
% In:
%     X: m x n dataset (m: number of samples, n:number of features) 
%     Y: m x 1 Targets
% Out:
%     filter: 3 x n matrix, contains scores of ranking algorithms

% Copyright (c) 2015 by Mohammad Kazem Ebrahimpour & Mahdi Eftekhari

function [filter]=filter_algorithms(X,Y)

% Fisher
fisher=fsFisher(X,Y);fisher_weights=fisher.W;
fisher_weights=fisher_weights./(max(fisher_weights));
% Information Gain
IG=fsInfoGain(X,Y);IG_weights=IG.W;ma=max(IG_weights);
if ma~=0IG_weights=IG_weights./(ma);end
% Releif
relief=fsReliefF(X,Y);relief_weights=relief.W;
relief_weights=relief_weights./(max(relief_weights));
filter=[relief_weights;IG_weights;fisher_weights]; 
end
