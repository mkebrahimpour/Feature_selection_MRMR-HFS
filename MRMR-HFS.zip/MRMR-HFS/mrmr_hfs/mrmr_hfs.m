% function [features]=mrmr_hfs(X,Y)

% This function selects features according to the MRMR-HFS algorithm.
% The details of the algorithm can be find here:
%  M. K. Ebrahimpour and M. Eftekhari, 
% "Ensemble of Feature Selection Methods: A Hesitant Fuzzy Sets Approach," 
% Applied Soft Computing, 2016.
% In:
%     X: m x n dataset (m: number of samples, n:number of features) 
%     Y: m x 1 Targets
% Out:
%     features: 1 x ? vector, contains the best subset of features.

% Copyright (c) 2015 by Mohammad Kazem Ebrahimpour & Mahdi Eftekhari

function [features]=mrmr_hfs(X,Y)

try
    load_fspackage;    
    fprintf('Calculating pairwise similarity measures (Redundancy Part)...\n');
    [euclidean,pearson,cosinsim]=similarity_mesures(X);
    rff=(euclidean.^2+pearson.^2+cosinsim.^2)./3;
    
    fprintf('Calculating filter algorithms (Relevancy Part)...\n');
    [rcf]=filter_algorithms(X,Y);
    
    fprintf('Applying forward search... \n');
    [features]=best_first(rcf,rff,X);
    fprintf('Feature selection has been done!\n');
catch
    fprintf('Please run the program again.\n');
end



