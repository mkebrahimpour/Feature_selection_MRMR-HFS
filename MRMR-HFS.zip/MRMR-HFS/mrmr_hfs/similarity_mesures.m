% function [DG,pear,cosSim]=similarity_mesures(X)

% This function calculates pairwise similarity measures among features.
% Three similarity measures are: (1/euclidean);(abs(pearson correlation))
% (cosine similarity measures)
% In:
%     X: m x n dataset (m: number of samples, n:number of features)  
% Out:
%     DG:     n x n matrix contains 1/euclidean distance.
%     pear:   n x n matrix contains absolute value of pearson correlation coefficients.
%     cosSim: n x n matrix contains cosine similarity measures.

% Copyright (c) 2015 by Mohammad Kazem Ebrahimpour & Mahdi Eftekhari

function [DG,pear,cosSim]=similarity_mesures(X)

[~,n]=size(X); ds=X;
for i=1:n
    mat=repmat(ds(:,i),1,n); tmp=mat-ds; tmp=tmp.^2;
    tmp=sqrt(sum(tmp)); euclidean(i,:)=tmp;
end
euclidean=1./(euclidean);ind=find(isinf(euclidean));euclidean(ind)=1;DG=euclidean;
% *************************************************************************
pear=corr(ds);pear=abs(pear);
%**************************************************************************
for i=1:n
    mat=repmat(ds(:,i),1,n);tmp=mat.*ds;s=sum(tmp);
    mat=sqrt(sum(mat.^2));Ds=sqrt(sum(ds.^2));m=mat.*Ds;
    cosSim(i,:)=s./m;
end
end