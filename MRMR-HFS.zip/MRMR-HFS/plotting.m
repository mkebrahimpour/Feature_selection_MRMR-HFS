%  function []= plotting(X,Y,features)

% This function plots the dataset based on their first two features.
% In:
%     X       : m x n dataset (m: number of samples, n:number of features). 
%     Y       : m x 1 Targets.
%     features: 1 x ? vector of selected features.
% Out:

% Copyright (c) 2015 by Mohammad Kazem Ebrahimpour & Mahdi Eftekhari

function [] = plotting(X,Y,features)

X=X(:,features);
uqv=unique(Y); n=length(uqv); color={'bo','ro','go','mo','co','ko'};
  figure; clf;  hold on; title('Distribution of dataset after feature selection')
for i=1:n
    ind=find(Y==uqv(i)); tmp=X(ind,:); 
    plot( tmp(:,1),tmp(:,2),color{i});  
end
xlabel(strcat('f',num2str(features(1)))); 
ylabel(strcat('f',num2str(features(2))));